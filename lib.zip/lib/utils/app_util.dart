import 'package:get/get.dart';

class AppUtil{
  //get the height of the device
  static double getDeviceHeight() {
    return Get.height;
  }

  ///get the width of the device
  static double getDeviceWidth() {
    return Get.width;
  }
}